import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

BASE = "https://c1dfcbb0-9c8a-478f-8b6b-bc87e9fbdc62.challenge.ctf.show"

s = requests.Session()
s.verify = False
r = s.post(f"{BASE}/login", data={"username": "test", "password": "test"}, allow_redirects=False)
sid = s.cookies.get("session")
print(f"Logged in with sid={sid}")

# First, send a unique marker message
marker_msg = f"TESTMARKER_{sid[-8:]}"
s.post(f"{BASE}/message", data={"msg": marker_msg, "sessionid": sid})

# Now check /message GET again
print("=== /message GET after sending ===")
r = s.get(f"{BASE}/message")
print(f"Status: {r.status_code}")
print(f"Body:\n{r.text}")

# Check root for the message
print("\n=== /  after sending ===")
r = s.get(f"{BASE}/")
print(f"Body:\n{r.text}")

# Try message as GET with query params
print("\n=== /message with GET params ===")
for qp in [f"?msg={marker_msg}", f"?sessionid={sid}", "?view=1", "?show=1", "?all=1", "?read=1"]:
    r = s.get(f"{BASE}/message{qp}")
    if marker_msg[:10] in r.text or "Message" in r.text and len(r.text) > 300:
        print(f"  {qp}: {len(r.text)} bytes - HAS CONTENT")
        print(f"    {r.text[:300]}")
    else:
        print(f"  {qp}: {r.status_code} len={len(r.text)}")

# Check all headers on message page
print("\n=== Full response for /message ===")
r = s.get(f"{BASE}/message")
for k, v in r.headers.items():
    print(f"  {k}: {v}")