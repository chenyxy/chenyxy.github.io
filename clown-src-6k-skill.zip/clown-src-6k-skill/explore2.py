import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

BASE = "https://c1dfcbb0-9c8a-478f-8b6b-bc87e9fbdc62.challenge.ctf.show"

s = requests.Session()
s.verify = False
s.post(f"{BASE}/login", data={"username": "test", "password": "test"}, allow_redirects=False)

# Test OPTIONS request to understand CORS
print("=== OPTIONS / ===")
r = s.options(f"{BASE}/", headers={
    "Origin": "http://evil.com",
    "Access-Control-Request-Method": "POST",
    "Access-Control-Request-Headers": "Content-Type, Cookies",
})
for k, v in r.headers.items():
    print(f"  {k}: {v}")

print()
print("=== OPTIONS with custom origin ===")
r = s.options(f"{BASE}/message", headers={
    "Origin": "http://evil.com",
    "Access-Control-Request-Method": "POST",
})
for k, v in r.headers.items():
    print(f"  {k}: {v}")

# Also check what Access-Control-Allow-Origin is on GET
print()
print("=== GET / with evil origin ===")
r = s.get(f"{BASE}/", headers={"Origin": "http://evil.com"})
for k, v in r.headers.items():
    if "access-control" in k.lower():
        print(f"  {k}: {v}")

print()
print("=== GET / with ctf.show origin ===")
r = s.get(f"{BASE}/", headers={"Origin": "https://ctf.show"})
for k, v in r.headers.items():
    if "access-control" in k.lower():
        print(f"  {k}: {v}")

# Test sending message with different sessionid
print()
print("=== Message with custom sessionid ===")
for sid in ["", "test", "abc123", "admin", s.cookies.get("session", "")]:
    r = s.post(f"{BASE}/message", data={"msg": "test", "sessionid": sid})
    print(f"  sessionid={sid!r}: status={r.status_code} body={r.text.strip()[:50]}")

# Test if message endpoint reveals anything on different methods
print()
print("=== GET /message with query params ===")
for qp in ["?msg=test", "?sessionid=admin", "?admin=1", "?debug=1", "?source=1"]:
    r = s.get(f"{BASE}/message{qp}", allow_redirects=False)
    print(f"  {qp}: status={r.status_code}")

# Check HTTP headers sent
print()
print("=== Custom headers test ===")
for hdrs in [
    {"Cookie": "admin=True", "Admin": "true"},
    {"X-Admin": "1", "Role": "admin"},
    {"X-Forwarded-For": "127.0.0.1"},
    {"X-Real-IP": "127.0.0.1"},
    {"X-Forwarded-Host": "localhost"},
]:
    r = s.get(f"{BASE}/", headers=hdrs)
    print(f"  Headers {hdrs}: status={r.status_code} body={r.text[:80]}")